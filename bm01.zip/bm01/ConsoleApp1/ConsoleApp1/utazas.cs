﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Utazas
    {
        //2
        public Utazas(string sor)
        {
            string[] temp = sor.Split(' ');
            this.megallo = Convert.ToInt32(temp[0]);
            this.felszallas = temp[1];
            this.utasID = temp[2];
            this.tipus = temp[3];
            this.ervenyesseg = temp[4];
        }

        private int megallo { get; set; }
        private string felszallas { get; set; }
        private string utasID { get; set; } //nemszabad magyart angollal keverni
        private string tipus { get; set; }
        private string ervenyesseg { get; set; }

        private static List<Utazas> utazasok = Beolvasas("utasadat.txt").ToList();

        //3
        private static IEnumerable<Utazas> Beolvasas(string fnev)
        {
            foreach (var item in File.ReadAllLines(fnev))
            {
                yield return new Utazas(item);
            }

        }


        /*
         private static List<Utazas> Beolvasas(string fnev)
        {
            List<Utazas> temp = new List<Utazas>();
            foreach (var item in File.ReadAllLines(fnev))
            {
                temp.Add(new Utazas(item));
            }
            return temp;
        }
         */


        //4.1
        public static int utasokSzama => utazasok.Count();

        //4.2
        private bool felszalltJegy => tipus.Equals("JGY") && ervenyesseg != "0";
        private bool felszalltBerlet => !tipus.Equals("JGY") &&
            felszallas.Substring(0, 8).CompareTo(ervenyesseg) <= 0;
        private bool felszallt => felszalltJegy || felszalltBerlet;

        public static int felszalltFo = utazasok
            .Count(x => x.felszallt);

        //4.3
        public static int felszalltjegyfo = utazasok
            .Count(x => x.felszalltJegy);
        //4.4
        public static int felszalltBerletfo = utazasok
            .Count(x => x.felszalltBerlet);
        //4.5
        private bool ingyenes => tipus.Equals("NYP") || tipus.Equals("RVS") || tipus.Equals("GYK");

        private bool kedvezmenyes => tipus.Equals("TAB") || tipus.Equals("NYB");

        private bool teljes => tipus.Equals("FEB");

        public static int felszalltingyenesfo = utazasok
          .Count(x => x.ingyenes && x.felszalltBerlet);

        public static int felszalltkedvezmenyesfo = utazasok
          .Count(x => x.kedvezmenyes && x.felszalltBerlet);

        public static int felszalltteljesfo = utazasok
          .Count(x => x.teljes && x.felszalltBerlet);

        //4.6
        private static List<Tuple<int, int>> megalloFo => utazasok
            .GroupBy(x => x.megallo)
            .Select(x => Tuple.Create(x.Key, x.Count()))
            .OrderByDescending(x => x.Item2)
            .ToList();

        private static Tuple<int, int> megalloFoLegtobb => megalloFo.First();


        public static void getMegalloFoLegtobb() => Console.WriteLine($"\t a legtobb utas ({megalloFoLegtobb.Item2} fo) a {megalloFoLegtobb.Item1}. megalloban probalt felszallni");

        //4.7
        private static List<Tuple<int, int>> megalloBliccelloFo => utazasok
            .Where(x => !x.felszallt)
            .GroupBy(x => x.megallo)
            .Select(x => Tuple.Create(x.Key, x.Count()))
            .OrderByDescending(x => x.Item2)
            .ToList();

        private static Tuple<int, int> megalloBliccelloFoLegtobb => megalloBliccelloFo.First();

        public static void getMegalloBlicceloFoLegtobb() => Console.WriteLine($"\t a legtobb utas ({megalloBliccelloFoLegtobb.Item2}) a {megalloBliccelloFoLegtobb.Item1}. megalloban probalt bliccelni");

        //4.8
        private DateTime felszallDatum => new DateTime
            (
                Convert.ToInt32(felszallas.Substring(0, 4)),
                Convert.ToInt32(felszallas.Substring(4, 2)),
                Convert.ToInt32(felszallas.Substring(6, 2))
            );

        private DateTime ervenyessegiDatum => new DateTime
            (
                Convert.ToInt32(ervenyesseg.Substring(0, 4)),
                Convert.ToInt32(ervenyesseg.Substring(4, 2)),
                Convert.ToInt32(ervenyesseg.Substring(6, 2))
            );

        private int berletNap => (ervenyessegiDatum - felszallDatum).Days;

        private bool figyelmeztetes => felszalltBerlet && berletNap <= 3;
        private static List<Tuple<string, DateTime>> figyelmezetesek => utazasok
            .Where(x => x.figyelmeztetes)
            .Select(x => Tuple.Create(x.utasID, x.ervenyessegiDatum))
            .ToList();


        public static void figyelmeztetesFile(string fnev)
        {
            StreamWriter sw = new StreamWriter($"{fnev}.txt", false, Encoding.UTF8);
            figyelmezetesek.ForEach(x => sw.WriteLine($"{x.Item1} {x.Item2:yyyy-MM-dd}"));

            sw.Close();
        }

        //4.9
        private static bool joDatum(string datum)
            {
                try
                {
                    Convert.ToDateTime(datum);
                    return true;
                }
                catch (Exception)
                {

                    return false;
                }
            }

        public static int jegyara = 0;


        private static int jegyFoNap(DateTime datum) => utazasok
            .Count(x => x.felszalltJegy && x.felszallDatum.Equals(datum));

        private static int jegyNapBevetel(DateTime datum) => jegyFoNap(datum) * jegyara;


        public static void napbevetel(string datum)
        {
            if (joDatum(datum))
            {
                Console.WriteLine($"\tbevetel: {jegyNapBevetel(Convert.ToDateTime(datum)):c0}");
            }
            else Console.WriteLine("\tnem megfelelo bemenet");
        }

    }
}
