﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("4.1. feladat");
            Console.WriteLine($"\tutasok szama: {Utazas.utasokSzama}");

            Console.WriteLine("\n4.2. feladat");
            Console.WriteLine($"\tfelszallt utasok szama: {Utazas.felszalltFo}");

            Console.WriteLine("\n4.3. feladat");
            Console.WriteLine($"\tjeggyel utazok szama: {Utazas.felszalltjegyfo}");

            Console.WriteLine("\n4.4. feladat");
            Console.WriteLine($"\tberlettel utazok szama: {Utazas.felszalltBerletfo}");

            Console.WriteLine("\n4.5. feladat");
            Console.WriteLine($"\tteljes aru berlettel utazok szama: {Utazas.felszalltteljesfo} fo");
            Console.WriteLine($"\tkedvezmenyes aru berlettel utazok szama: {Utazas.felszalltkedvezmenyesfo} fo");
            Console.WriteLine($"\tingyenes berlettel utazok szama: {Utazas.felszalltingyenesfo} fo");

            Console.WriteLine("\n4.6. feladat");
            Utazas.getMegalloFoLegtobb();

            Console.WriteLine("\n4.7. feladat");
            Utazas.getMegalloBlicceloFoLegtobb();

            Console.WriteLine("\n4.8. feladat");
            Console.WriteLine("\tfigyelmeztetes.txt");
            Utazas.figyelmeztetesFile("figyelmeztetes");

            Console.WriteLine("\n4.9. feladat");
            Console.WriteLine("\tkerem add meg a felszallas datumat [2019-03-26]: ");
            Utazas.jegyara = 400;
            Utazas.napbevetel(Console.ReadLine());

            Console.ReadKey();
        }
    }
}
