﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vasMegyeOOP12K2
{
    class Csecsemo
    {
        private Csecsemo(string szemelyiSzam)
        {
            this.szemelyiSzam = szemelyiSzam;
        }

        private string szemelyiSzam { get; set; }
        private string szemelyiSzamDigit => szemelyiSzam.Replace("-","");

        private bool nemeFiu => szemelyiSzam.First() == '1' || szemelyiSzam.First() == '3';

        private int getSzuletseiEv => szemelyiSzam.First() == '1' || szemelyiSzam.First() == '2' ?
            Convert.ToInt32(szemelyiSzam.Substring(2, 2)) + 1900 :
            Convert.ToInt32(szemelyiSzam.Substring(2, 2)) + 2000;

        private static List<Csecsemo> csecsemok = new List<Csecsemo>();
        private static List<Csecsemo> hibas = new List<Csecsemo>();


        public static void Beolvasas(string fnev)
        {
            //string[] temp = File.ReadAllLines(fnev);
            foreach (var item in File.ReadAllLines(fnev))
            {
                if(new Csecsemo(item).CdvEll()) csecsemok.Add(new Csecsemo(item));
                else hibas.Add(new Csecsemo(item));
            }
        }

        public static void getHibasSzemelyiSzamok() =>
            hibas.ForEach(x => Console.WriteLine($"\tHibás a {x.szemelyiSzam} szeméyi azonosító!"));

        public static int getFiukSzama => csecsemok.Count(x => x.nemeFiu);
        //public static int getLanyokSzama => csecsemok.Count(x => !x.nemeFiu);
        public static int getLanyokSzama => csecsemok.Count() - getFiukSzama;

        public static int getKezdoEv => csecsemok.Min(x => x.getSzuletseiEv);
        public static int getBefejezoEv => csecsemok.Max(x => x.getSzuletseiEv);


        private static int vizsgaltEvFo(int ev) => csecsemok
            .Count(x => x.getSzuletseiEv.Equals(ev));

        public static string getVizsgaltEvFo(int ev)
        {
            int fo = vizsgaltEvFo(ev);
            return fo != 0 ?
            $"{fo:n0} fő" :
            "Nincs adatt a megadott évről.";
        }

        private static int vizsgaltEvNemeFo(int ev, bool fiu) => csecsemok
            .Count(x => x.getSzuletseiEv.Equals(ev) && x.nemeFiu==fiu);


        public static string getVizsgaltEvNemeFo(int ev, bool fiu)
        {
            int fo = vizsgaltEvNemeFo(ev, fiu);
            return fo != 0 ?
            $"{fo:n0} fő" :
            "Nincs adatt a megadott évről.";
        }


        private static List<Tuple<int, int>> evenkentiSzuletesekFo => csecsemok
            .GroupBy(x => x.getSzuletseiEv)
            .Select(x => Tuple.Create(x.Key, x.Count()))
            .OrderBy(x => x.Item1)
            .ToList();

        public static void getEvenkentiSzuletesekFo() => evenkentiSzuletesekFo
            .ForEach(x => Console.WriteLine($"\t{x.Item1} - {x.Item2:n0} fő"));



        private bool CdvEll()
        {
            int sorszam = 10;
            int osszegSzorzat = 0;
            for (int i = 0; i < szemelyiSzamDigit.Length-1; i++)
            {
                osszegSzorzat += Convert.ToInt32(szemelyiSzamDigit[i].ToString()) * sorszam;
                sorszam--;
            }

            return osszegSzorzat % 11 == Convert.ToInt32(szemelyiSzamDigit[10].ToString());
        }

    }
}
