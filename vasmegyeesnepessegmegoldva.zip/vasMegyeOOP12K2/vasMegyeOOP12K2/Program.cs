﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vasMegyeOOP12K2
{
    class Program
    {
        static void Main(string[] args)
        {
            Csecsemo.Beolvasas("vas.txt");

            Console.WriteLine("6. feladat");
            Console.WriteLine("\tHibás személyi azonosítók:");
            Csecsemo.getHibasSzemelyiSzamok();

            Console.WriteLine("\n7. feladat");
            Console.WriteLine($"\tFiúk száma: {Csecsemo.getFiukSzama:n0} fő");
            Console.WriteLine($"\tLányok száma: {Csecsemo.getLanyokSzama:n0} fő");

            Console.WriteLine("\n8. feladat");
            Console.WriteLine($"\tVizsgált időszak: {Csecsemo.getKezdoEv} - {Csecsemo.getBefejezoEv}");

            Console.WriteLine("\n10. feladat");
            Console.WriteLine($"\t2000-ben született csecsemők száma: {Csecsemo.getVizsgaltEvFo(2000)}");
            Console.WriteLine($"\t2010-ben született csecsemők száma: {Csecsemo.getVizsgaltEvFo(2010)}");

            Console.WriteLine("\n12. feladat");
            Console.WriteLine($"\t2000-ben született fiú csecsemők száma: {Csecsemo.getVizsgaltEvNemeFo(2000, true)}");
            Console.WriteLine($"\t2000-ben született lány csecsemők száma: {Csecsemo.getVizsgaltEvNemeFo(2000, false)}");
            Console.WriteLine($"\t2010-ben született fiú csecsemők száma: {Csecsemo.getVizsgaltEvNemeFo(2010, true)}");

            Console.WriteLine("\n14. feladat");
            Console.WriteLine("\tÉvenkénti születések száma:");
            Csecsemo.getEvenkentiSzuletesekFo();

            Console.ReadKey();
        }
    }
}
