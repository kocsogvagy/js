﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nepessegOOP12K2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("5. feladat");
            Console.WriteLine($"\tOrszágok száma: {Orszag.orszagokSzama} db");

            Console.WriteLine("\n7. feladat");
            Console.WriteLine($"\tKína népsűrűsége: {Orszag.OrszagNepsuruseg("Kína")}");
            Console.WriteLine($"\tMagyarország népsűrűsége: {Orszag.OrszagNepsuruseg("Magyarország")}");
            Console.WriteLine($"\tIrak népsűrűsége: {Orszag.OrszagNepsuruseg("Irak")}");

            Console.WriteLine("\n8. feladat");
            Console.WriteLine("\tKínában hány fővel éltek többen a vizsggált időpontban, mint Indiában?");
            Console.WriteLine($"\tLakosság különbség: {Orszag.LakossagKulonbseg("Kína","India")}");
            Console.WriteLine("\tSzlovákiában hány fővel éltek többen a vizsggált időpontban, mint Magyarországon?");
            Console.WriteLine($"\tLakosság különbség: {Orszag.LakossagKulonbseg("Szlovákia", "Magyarország")}");
            Console.WriteLine("\tIrakban hány fővel éltek többen a vizsggált időpontban, mint Szlovákiában?");
            Console.WriteLine($"\tLakosság különbség: {Orszag.LakossagKulonbseg("Irak", "Szlovákia")}");

            Console.WriteLine("\n9. feladat");
            Console.WriteLine($"\t3. legnépesebb ország: {Orszag.LegnepesebbOrszagNeve(3)}, lakossága: {Orszag.LegnepesebbOrszagLakossaga(3)}");
            Console.WriteLine($"\t300. legnépesebb ország: {Orszag.LegnepesebbOrszagNeve(300)}, lakossága: {Orszag.LegnepesebbOrszagLakossaga(300)}");

            Console.WriteLine("\n11. feladat");
            Console.WriteLine("\tOrszákok melyeknél a fővárosban lakók aránya meghaladja a 30%-ot.");
            Orszag.getOrszagokFovarosLegalabb30();

            Console.ReadKey();
        }
    }
}
