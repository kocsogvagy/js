﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nepessegOOP12K2
{
    class Orszag
    {

        private string orszagNev { get; set; }
        private int terulet { get; set; }
        private int nepesseg { get; set; }
        private string fovaros { get; set; }
        private int fovarosNepessege { get; set; }
        
        
        public Orszag(string sor)
        {
            string[] temp = sor.Split(';');
            this.orszagNev = temp[0];
            this.terulet = Convert.ToInt32(temp[1]);
            if (temp[2].Contains("g")) this.nepesseg = Convert.ToInt32(temp[2].Replace("g", "")) * 10000;
            else this.nepesseg = Convert.ToInt32(temp[2]);
            this.fovaros = temp[3];
            this.fovarosNepessege = Convert.ToInt32(temp[4])*1000;
        }

        private static List<Orszag> orszagok = Beolvasas("adatok-utf8.txt").ToList();

        //private static List<Orszag> Beolvasas(string fnev)
        //{
        //    List<Orszag> Temp = new List<Orszag>();
        //    foreach (var item in File.ReadAllLines(fnev).Skip(1))
        //    {
        //        Temp.Add(new Orszag(item));
        //    }
        //    return Temp;
        //}

        private static IEnumerable<Orszag> Beolvasas(string fnev)
        {
            foreach (var item in File.ReadAllLines(fnev).Skip(1))
            {
                yield return new Orszag(item);
            }
        }

        private double nepsuruseg => Math.Round((double)nepesseg / terulet, 0);

        private static Orszag OrszagKeres(string orszagNev) => orszagok
            .FirstOrDefault(x => x.orszagNev.Equals(orszagNev));

        public static string OrszagNepsuruseg(string orszagNev)
        {
            Orszag keresettOrszag = OrszagKeres(orszagNev);
            return keresettOrszag != null ?
                $"{keresettOrszag.nepsuruseg:n0} fő/km2" :
                $"az ország nem található az adatbázisban.";
        }

        public static string LakossagKulonbseg(string orszagNev1, string orszagNev2)
        {
            Orszag keresettOrszag1 = OrszagKeres(orszagNev1);
            Orszag keresettOrszag2 = OrszagKeres(orszagNev2);
            return keresettOrszag1 != null && keresettOrszag2 != null ?
                $"{keresettOrszag1.nepesseg-keresettOrszag2.nepesseg:n0} fő" :
                $"az ország nem található az adatbázisban.";
        }
        public static int orszagokSzama => orszagok.Count();


        private static Orszag LegnepesebbOrszag(int sorszam) => orszagok
            .OrderByDescending(x => x.nepesseg)
            .ElementAtOrDefault(sorszam);

        public static string LegnepesebbOrszagNeve(int sorszam)
        {
            Orszag keresett = LegnepesebbOrszag(sorszam);
            return keresett != null ? keresett.orszagNev : "nincs adat";
        }

        public static string LegnepesebbOrszagLakossaga(int sorszam)
        {
            Orszag keresett = LegnepesebbOrszag(sorszam);
            return keresett != null ? $"{keresett.nepesseg:n0} fő" : "nincs adat";
        }

        private double fovarosLakossagaLegalabb30SzazalekErtek => (double)fovarosNepessege / nepesseg;
        private bool fovarosLakossagaLegalabb30Szazalek => fovarosLakossagaLegalabb30SzazalekErtek > 0.3;

        private static List<Tuple<string, string, double>> orszagokFovarosLegalabb30 => orszagok
            .Where(x => x.fovarosLakossagaLegalabb30Szazalek)
            .Select(x => Tuple.Create(x.orszagNev, x.fovaros, x.fovarosLakossagaLegalabb30SzazalekErtek))
            .ToList();

        public static void getOrszagokFovarosLegalabb30() => orszagokFovarosLegalabb30
            .ForEach(x => Console.WriteLine($"\t{x.Item1,-20} {x.Item2,-20} {x.Item3:p2}"));
    }
}
